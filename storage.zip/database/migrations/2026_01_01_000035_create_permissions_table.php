<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('permissions', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name', 40)->nullable();
            $table->string('group', 40)->nullable();
            $table->string('code', 255)->nullable();
        });
    }

    public function down()
    {
        Schema::dropIfExists('permissions');
    }
};
